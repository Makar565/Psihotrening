from kivy.app import App
from kivy.uix.button import Button
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.recycleview import RecycleView
from kivy.uix.gridlayout import GridLayout
from kivy.core.window import Window
from kivy.config import ConfigParser
from kivy.uix.textinput import TextInput
from kivy.uix.label import Label
from kivy.metrics import dp
from datetime import datetime
import os
import ast
import time

import em_model
from em_model import start
emotion=''
em_ind={'angry':100, 'disgusted':100, 'fearful':100, 'happy':100, 'sad':100, 'surprised':100, 'neutral':110}
emotions_eng = ['angry', 'disgusted', 'fearful', 'happy', 'sad', 'surprised', 'neutral']
screen_emo=['scr_angry', 'scr_disgusted', 'scr_fearful', 'scr_happy', 'scr_sad', 'scr_surprised', 'scr_neutral']
emotion_rus=['Гнев','Отвращение','Страх','Радость','Печаль','Удивление','Нейтральный']
class MenuScreen(Screen):
    def __init__(self, **kw):
        super(MenuScreen, self).__init__(**kw)
        box = BoxLayout(orientation='vertical')
        
        box.add_widget(Button(text='Тренировка "'+emotion_rus[0]+'"' , on_press=lambda x:set_screen('scr_angry',emotions_eng[0])))
        box.add_widget(Button(text='Тренировка "'+emotion_rus[1]+'"' , on_press=lambda x:set_screen('scr_disgusted',emotions_eng[1])))
        box.add_widget(Button(text='Тренировка "'+emotion_rus[2]+'"' , on_press=lambda x:set_screen('scr_fearful',emotions_eng[2])))
        box.add_widget(Button(text='Тренировка "'+emotion_rus[3]+'"' , on_press=lambda x:set_screen('scr_happy',emotions_eng[3])))
        box.add_widget(Button(text='Тренировка "'+emotion_rus[4]+'"' , on_press=lambda x:set_screen('scr_sad',emotions_eng[4])))
        box.add_widget(Button(text='Тренировка "'+emotion_rus[5]+'"' , on_press=lambda x:set_screen('scr_surprised',emotions_eng[5])))
        box.add_widget(Button(text='Тренировка "'+emotion_rus[6]+'"' , on_press=lambda x:set_screen('scr_neutral',emotions_eng[6])))
        box.add_widget(Button(text='Инструкция по пользованию' , on_press=lambda x:set_screen('learn','')))
        self.add_widget(box)
class instruction(Screen):
    
    def __init__(self, **kw):
        super(instruction, self).__init__(**kw)

    def on_enter(self): # Будет вызвана в момент открытия экрана
        self.layout = GridLayout(cols=1, spacing=10, size_hint_y=None)
        self.layout.bind(minimum_height=self.layout.setter('height'))
        back_button = Button(text='< Назад в главное меню',
                             on_press=lambda x: set_screen('menu',''),
                             size_hint_y=None, height=dp(40))
        self.layout.add_widget(back_button)
        root = RecycleView(size_hint=(1, None), size=(Window.width,
                                                      Window.height))
        root.add_widget(self.layout)
        self.add_widget(root)

        dic_foods = ast.literal_eval(
            App.get_running_app().config.get('General', 'user_data'))
        mylabel = Label(text= "Инструкция в разработке")
        self.add_widget(mylabel)
        
        
   
class emotion6(Screen):
    
    def __init__(self, **kw):
        super(emotion6, self).__init__(**kw)

    def on_enter(self): # Будет вызвана в момент открытия экрана
        global emotion
        mylabel = Label(text= emotion_rus[emotions_eng.index(emotion)])
        self.add_widget(mylabel)
        import em_model
        from em_model import start
        
        start.r(emotion,em_ind[emotion])
        
        
        self.layout = GridLayout(cols=1, spacing=10, size_hint_y=None)
        self.layout.bind(minimum_height=self.layout.setter('height'))
        back_button = Button(text='< Назад в главное меню',
                             on_press=lambda x: set_screen('menu',''),
                             size_hint_y=None, height=dp(40))
        self.layout.add_widget(back_button)
        root = RecycleView(size_hint=(1, None), size=(Window.width,
                                                      Window.height))
        root.add_widget(self.layout)
        self.add_widget(root)

        dic_foods = ast.literal_eval(
            App.get_running_app().config.get('General', 'user_data'))
        mylabel = Label(text= "Молодец ты прошел тренировку "+emotion_rus[emotions_eng.index(emotion)])
        self.layout.add_widget(mylabel)
        
    
class emotion5(Screen):
    
    def __init__(self, **kw):
        super(emotion5, self).__init__(**kw)

    def on_enter(self): # Будет вызвана в момент открытия экрана
        global emotion
        mylabel = Label(text= emotion_rus[emotions_eng.index(emotion)])
        self.add_widget(mylabel)
        import em_model
        from em_model import start
        
        start.r(emotion,em_ind[emotion])
        
        
        self.layout = GridLayout(cols=1, spacing=10, size_hint_y=None)
        self.layout.bind(minimum_height=self.layout.setter('height'))
        back_button = Button(text='< Назад в главное меню',
                             on_press=lambda x: set_screen('menu',''),
                             size_hint_y=None, height=dp(40))
        self.layout.add_widget(back_button)
        root = RecycleView(size_hint=(1, None), size=(Window.width,
                                                      Window.height))
        root.add_widget(self.layout)
        self.add_widget(root)

        dic_foods = ast.literal_eval(
            App.get_running_app().config.get('General', 'user_data'))
        mylabel = Label(text= "Молодец ты прошел тренировку "+emotion_rus[emotions_eng.index(emotion)])
        self.layout.add_widget(mylabel)

        
        
    
class emotion4(Screen):
    
    def __init__(self, **kw):
        super(emotion4, self).__init__(**kw)

    def on_enter(self): # Будет вызвана в момент открытия экрана
        global emotion
        mylabel = Label(text= emotion_rus[emotions_eng.index(emotion)])
        self.add_widget(mylabel)
        import em_model
        from em_model import start
        
        start.r(emotion,em_ind[emotion])
        
        
        self.layout = GridLayout(cols=1, spacing=10, size_hint_y=None)
        self.layout.bind(minimum_height=self.layout.setter('height'))
        back_button = Button(text='< Назад в главное меню',
                             on_press=lambda x: set_screen('menu',''),
                             size_hint_y=None, height=dp(40))
        self.layout.add_widget(back_button)
        root = RecycleView(size_hint=(1, None), size=(Window.width,
                                                      Window.height))
        root.add_widget(self.layout)
        self.add_widget(root)

        dic_foods = ast.literal_eval(
            App.get_running_app().config.get('General', 'user_data'))
        mylabel = Label(text= "Молодец ты прошел тренировку "+emotion_rus[emotions_eng.index(emotion)])
        self.layout.add_widget(mylabel)

        
        
   
class emotion3(Screen):
    
    def __init__(self, **kw):
        super(emotion3, self).__init__(**kw)

    def on_enter(self): # Будет вызвана в момент открытия экрана
        global emotion
        mylabel = Label(text= emotion_rus[emotions_eng.index(emotion)])
        self.add_widget(mylabel)
        import em_model
        from em_model import start
        
        start.r(emotion,em_ind[emotion])
        
        
        self.layout = GridLayout(cols=1, spacing=10, size_hint_y=None)
        self.layout.bind(minimum_height=self.layout.setter('height'))
        back_button = Button(text='< Назад в главное меню',
                             on_press=lambda x: set_screen('menu',''),
                             size_hint_y=None, height=dp(40))
        self.layout.add_widget(back_button)
        root = RecycleView(size_hint=(1, None), size=(Window.width,
                                                      Window.height))
        root.add_widget(self.layout)
        self.add_widget(root)

        dic_foods = ast.literal_eval(
            App.get_running_app().config.get('General', 'user_data'))
        mylabel = Label(text= "Молодец ты прошел тренировку "+emotion_rus[emotions_eng.index(emotion)])
        self.layout.add_widget(mylabel)

        
        
    
class emotion2(Screen):
    
    def __init__(self, **kw):
        super(emotion2, self).__init__(**kw)

    def on_enter(self): # Будет вызвана в момент открытия экрана
        global emotion
        mylabel = Label(text= emotion_rus[emotions_eng.index(emotion)])
        self.add_widget(mylabel)
        import em_model
        from em_model import start
        
        start.r(emotion,em_ind[emotion])
        
        
        self.layout = GridLayout(cols=1, spacing=10, size_hint_y=None)
        self.layout.bind(minimum_height=self.layout.setter('height'))
        back_button = Button(text='< Назад в главное меню',
                             on_press=lambda x: set_screen('menu',''),
                             size_hint_y=None, height=dp(40))
        self.layout.add_widget(back_button)
        root = RecycleView(size_hint=(1, None), size=(Window.width,
                                                      Window.height))
        root.add_widget(self.layout)
        self.add_widget(root)

        dic_foods = ast.literal_eval(
            App.get_running_app().config.get('General', 'user_data'))
        mylabel = Label(text= "Молодец ты прошел тренировку "+emotion_rus[emotions_eng.index(emotion)])
        self.layout.add_widget(mylabel)

        
        
   
class emotion1(Screen):
    
    def __init__(self, **kw):
        super(emotion1, self).__init__(**kw)

    def on_enter(self): # Будет вызвана в момент открытия экрана
        global emotion
        mylabel = Label(text= emotion_rus[emotions_eng.index(emotion)])
        self.add_widget(mylabel)
        import em_model
        from em_model import start
        
        start.r(emotion,em_ind[emotion])
        
        
        self.layout = GridLayout(cols=1, spacing=10, size_hint_y=None)
        self.layout.bind(minimum_height=self.layout.setter('height'))
        back_button = Button(text='< Назад в главное меню',
                             on_press=lambda x: set_screen('menu',''),
                             size_hint_y=None, height=dp(40))
        self.layout.add_widget(back_button)
        root = RecycleView(size_hint=(1, None), size=(Window.width,
                                                      Window.height))
        root.add_widget(self.layout)
        self.add_widget(root)

        dic_foods = ast.literal_eval(
            App.get_running_app().config.get('General', 'user_data'))
        mylabel = Label(text= "Молодец ты прошел тренировку "+emotion_rus[emotions_eng.index(emotion)])
        self.layout.add_widget(mylabel)
        
        
   
class emotion0(Screen):
    
    def __init__(self, **kw):
        super(emotion0, self).__init__(**kw)

    def on_enter(self): # Будет вызвана в момент открытия экрана
        global emotion
        mylabel = Label(text= emotion_rus[emotions_eng.index(emotion)])
        self.add_widget(mylabel)
        import em_model
        from em_model import start
        
        start.r(emotion,em_ind[emotion])
        
        
        self.layout = GridLayout(cols=1, spacing=10, size_hint_y=None)
        self.layout.bind(minimum_height=self.layout.setter('height'))
        back_button = Button(text='< Назад в главное меню',
                             on_press=lambda x: set_screen('menu',''),
                             size_hint_y=None, height=dp(40))
        self.layout.add_widget(back_button)
        root = RecycleView(size_hint=(1, None), size=(Window.width,
                                                      Window.height))
        root.add_widget(self.layout)
        self.add_widget(root)

        dic_foods = ast.literal_eval(
            App.get_running_app().config.get('General', 'user_data'))
        mylabel = Label(text= "Молодец ты прошел тренировку "+emotion_rus[emotions_eng.index(emotion)])
        self.layout.add_widget(mylabel)
        
        
    



def set_screen(name_screen,emot):
    global emotion
    emotion=emot
    sm.current = name_screen

sm = ScreenManager()
sm.add_widget(MenuScreen(name='menu'))
sm.add_widget(emotion0(name=screen_emo[0]))
sm.add_widget(emotion1(name=screen_emo[1]))
sm.add_widget(emotion2(name=screen_emo[2]))
sm.add_widget(emotion3(name=screen_emo[3]))
sm.add_widget(emotion4(name=screen_emo[4]))
sm.add_widget(emotion5(name=screen_emo[5]))
sm.add_widget(emotion6(name=screen_emo[6]))
sm.add_widget(instruction(name='learn'))
class PsychoTrainer(App):
    def __init__(self, **kvargs):
        super(PsychoTrainer, self).__init__(**kvargs)
        self.config = ConfigParser()

    def build_config(self, config):
        config.adddefaultsection('General')
        config.setdefault('General', 'user_data', '{}')

    def set_value_from_config(self):
        self.config.read(os.path.join(self.directory, '%(appname)s.ini'))
        self.user_data = ast.literal_eval(self.config.get(
            'General', 'user_data'))

    def get_application_config(self):
        return super(PsychoTrainer, self).get_application_config(
            '{}/%(appname)s.ini'.format(self.directory))

    def build(self):
        return sm


if __name__ == '__main__':
    PsychoTrainer().run()
