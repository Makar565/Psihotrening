# Psycho Trainer

A real time system to detect human emotions from image.


# Prerequisites
```
Python 3
OpenCV
```
# Installation
```
pip install tensorflow numpy scipy h5py
```
Download the trained model from the links given in source/trained-model.txt
# Testing
```
python main.py
```

